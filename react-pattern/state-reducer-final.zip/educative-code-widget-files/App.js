//import React from 'react'
import React, { useRef } from 'react'
import { longText as TermsAndConditionText } from './components/utils'
import useExpanded, { useEffectAfterMount } from './components/Expandable'
import Header from './components/Header'
import Icon from './components/Icon'
import Body from './components/Body'

import './App.css'
import './components/Expandable.css'

// the user's app 👇
function App () {
  // ref holds boolean value to decide if user has viewed secret or not 
  const hasViewedSecret = useRef(false) // 👈 initial value is false
  // hacker calls our custom hook 👇
  const { expanded, toggle, reset, resetDep = 0 } = useExpanded(
    false,
    appReducer // 👈 hacker passes in their reducer  
  )

  // The user's reducer
  // Remember that action is populated with our internalChanges
  function appReducer (currentInternalState, action) {
    // dont updated "expanded" if reader has viewed secret
    // i.e hasViewedSecret.current === true 
    if (hasViewedSecret.current) {
     // object returned represents new state proposed by hacker
      return {
        ...action.internalChanges,
        // override internal update
        expanded: false
      }
    }
    
    // else, hacker is okay with our internal changes
    return action.internalChanges
  }

  useEffectAfterMount(
    () => {
      // open secret in new tab 👇
      window.open('https://leanpub.com/reintroducing-react', '_blank')
      //after viewing secret, hacker sets the ref value to true. 
      hasViewedSecret.current = true
    },
    [resetDep]
  )
  return (
    <section className='App'>
      <div className='Expandable'>
        <Header toggle={toggle} style={{ border: '1px dotted red' }}>
          They've been lying to you
        </Header>        
        <Icon expanded={expanded} />
        <Body expanded={expanded} style={{ background: 'papayawhip' }}>	
          <p>
            Click to view the conspiracy <br />
            <button onClick={reset}> View secret </button>
          </p>
        </Body>
      </div>
    </section>
  )
}

export default App
